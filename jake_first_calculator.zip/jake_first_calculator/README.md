# Jake's First Calculator

A simple desktop calculator made with Python and Tkinter.

## Features
- Addition
- Subtraction
- Multiplication
- Division
- Decimal number support
- Input validation
- Protection against division by zero
- Clear button

## Requirements
- Python 3
- Tkinter (usually included with Python)

No extra Python packages are required.

## How to run

1. Install Python 3 if it is not already installed.
2. Download and extract this project ZIP.
3. Open the project folder in Visual Studio Code, IDLE, or another Python editor.
4. Open a terminal in the project folder.
5. Run:

   ```bash
   python main.py
   ```

   On some computers, use:

   ```bash
   python3 main.py
   ```

6. Enter two numbers, choose an operation, and click **Calculate**.

## How the program works

1. Tkinter creates the calculator window and its controls.
2. The user enters two numbers.
3. The user selects an operation.
4. The `calculate()` function reads the values and performs the selected math operation.
5. The answer appears in the result area.
6. The program checks invalid input and prevents division by zero.

## Main Python concepts used
- Variables
- Functions
- `if`, `elif`, and `else`
- `try` and `except`
- Number conversion with `float()`
- Tkinter labels, buttons, entries, and a dropdown

## Project information
**Author:** Jake Astillero  
**Section:** BSIT-1C  
**Project:** First Python Calculator
